﻿using System;
using System.Text.Json;
using System.IO;
using System.Security.Cryptography;
using System.Collections.Generic;
namespace IT_Sec
{
    class Program
    {
        static void Main(string[] args)
        {
           Input hej = new Input();
            
            hej.Välkommen();
        }

    }
}
