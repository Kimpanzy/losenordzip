﻿using System.Collections.Generic;
using System.Text.Json;
using System;
using System.IO;
using System.Security.Cryptography;

namespace IT_Sec
{
    public class Input
    {
        public void Välkommen()
        {
            string clientFile = "";
            string serverFile = "";
            string readFile = "";
            string masterpassword = "grupp";
            Console.WriteLine("Ange lösenord: ");
            string input = Console.ReadLine();
            if (input == masterpassword)
            {
                Console.WriteLine("Vad vill du göra? \n" +
                    "1. Skapa en fil.\n" +
                    "2. Läsa en fil.\n" +
                    "3. Lägg till något.\n");
                int.TryParse(Console.ReadLine(), out int siffra);
                switch (siffra)
                {

                    case 1:
                        Console.WriteLine("Ange server namn: ");
                        serverFile = Console.ReadLine();
                        Console.WriteLine("Ange client namn: ");
                        clientFile = Console.ReadLine();
                        init(clientFile, serverFile, masterpassword);
                        //Console.WriteLine("Vill du lägga till något?\n1. Ja.\n2. Nej.");

                        //int.TryParse(Console.ReadLine(), out int opt);
                        //if (opt == 1)
                        //{
                        //    Console.WriteLine("Ange ett användarnamn: ");
                        //    string anvandar = Console.ReadLine();
                        //    Console.WriteLine("Ange ett lösenord: ");
                        //    string _password = Console.ReadLine();
                        //    clientDict.Add(anvandar, _password);
                        //    string _content = JsonSerializer.Serialize(clientDict);
                        //    File.AppendAllText(clientFile + ".txt", _content);
                        //    File.AppendAllText(serverFile + ".txt", _content);

                        //}
                        break;
                    case 2:
                        string _input = Console.ReadLine();
                        Secret(_input);
                        //Console.WriteLine("Ange clientfil");
                        // clientFile = Console.ReadLine();
                        //Console.WriteLine("Ange serverfil");
                        // serverFile = Console.ReadLine();
                        //Console.WriteLine("Ange masterpassword");
                        //string master = Console.ReadLine();
                        //Console.WriteLine("Ange secretkey");
                        //string secret = Console.ReadLine();
                        //if (master == masterpassword && secret = secretkeyread)
                        //    create(clientFile, serverFile,secretkey)
                        break;
                    case 3:
                        Console.Write("Filnamn: ");
                        string addToClient = Console.ReadLine();
                        Console.WriteLine("Ange ett användarnamn:");
                        string username = Console.ReadLine();
                        Console.WriteLine("Ange ett lösenord:");
                        string password1 = Console.ReadLine();
                        Dictionary<string, string> currentDict = new Dictionary<string, string>();
                        currentDict.Add(username, password1);
                        string content = JsonSerializer.Serialize(currentDict);
                        File.AppendAllText(addToClient + ".txt", content);

                     

                        break;
                }
            }
            else
                Console.WriteLine("Felaktigt lösenord");
        }
 
       public static void init(string clientFile, string serverFile, string password)
        {
            RandomNumberGenerator rng = RandomNumberGenerator.Create();
            byte[] secretkey = new byte[16];
            rng.GetBytes(secretkey);
            byte[] IV = new byte[16];
            rng.GetBytes(IV);

            Rfc2898DeriveBytes rfcKey = new Rfc2898DeriveBytes(password, secretkey, 1000, HashAlgorithmName.SHA256);
            byte[] vaultKey = rfcKey.GetBytes(16);

            string secretString = Convert.ToBase64String(secretkey);
            string ivString = Convert.ToBase64String(IV);
            //Client
            Dictionary<string, string> clientDict = new Dictionary<string, string>();
            clientDict.Add("Secret key", secretString);
            string clientContent = JsonSerializer.Serialize(clientDict);
            File.AppendAllText(clientFile + ".txt", clientContent);
            //Vault
            Dictionary<string, string> vault = new Dictionary<string, string>();
            string jsonVault = JsonSerializer.Serialize(vault);
            //Server
            byte[] encryptedVault = kryptering.EncryptStringToBytes_Aes(jsonVault, vaultKey, IV);
            string encryptedVaultString = Convert.ToBase64String(encryptedVault);
            Dictionary<string, string> serverDict = new Dictionary<string, string>();
            serverDict.Add("Vault", encryptedVaultString);
            serverDict.Add("IV", ivString);
            string serverContent = JsonSerializer.Serialize(serverDict);
            File.AppendAllText(serverFile + ".txt", serverContent);

        }
        public static void create(string clientFile, string serverFile, string password, string secretString)
        {
            if (!File.Exists(serverFile))
            {
                Console.WriteLine("Serverfilen existera inte!");
                Environment.Exit(0);
            }
            try
            {
                Dictionary<string, string> newClientDict = new Dictionary<string, string>();
                newClientDict.Add("SecretKey", secretString);
                string newClient = JsonSerializer.Serialize(newClientDict);
                File.AppendAllText(clientFile + ".txt", newClient);
                
            }
            catch
            {

            }
        }
        public static void Secret(string clientFile)
        {
            string clientSecret;

            clientSecret = File.ReadAllText(clientFile+ ".txt");
            var clientDict = JsonSerializer.Deserialize<Dictionary<string, string>>(clientSecret);
            Console.WriteLine(clientDict["Secret key"]);
        }
    }
}
